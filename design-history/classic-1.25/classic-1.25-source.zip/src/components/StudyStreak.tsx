import { useEffect, useState } from 'react'
import type { StudyActivity } from '../lib/activity'
import { studyStreak } from '../lib/activity'
import './study-streak.css'

export function StudyStreak({activity,error}:{activity:StudyActivity;error?:string}) {
  const [now,setNow]=useState(()=>new Date())
  useEffect(()=>{const refresh=()=>setNow(new Date());const timer=window.setInterval(refresh,60000);document.addEventListener('visibilitychange',refresh);return()=>{window.clearInterval(timer);document.removeEventListener('visibilitychange',refresh)}},[])
  const streak=studyStreak(activity,now)
  return <section className="study-streak" aria-label="Серия занятий">
    <div className="streak-main"><span aria-hidden="true" className="streak-symbol">✦</span><div><h2>Серия занятий · {streak.current}</h2><p>{streak.today ? 'Сегодня вы уже занимались' : streak.current ? 'Продолжите серию сегодня' : 'Начните серию сегодня'}</p></div><strong title="Самая длинная серия">Рекорд: {streak.best}</strong></div>
    <div className="streak-week" aria-label="Последние семь дней">{streak.week.map(day=><span key={day.day} className={`${day.active ? 'is-active' : ''} ${day.today ? 'is-today' : ''}`} aria-label={`${new Date(day.day+'T12:00:00').toLocaleDateString('ru-RU')}: ${day.active ? 'занимались' : 'нет занятия'}`}><time dateTime={day.day}>{new Date(day.day+'T12:00:00').toLocaleDateString('ru-RU',{weekday:'short'})}</time><span aria-hidden="true">{day.active ? '✓' : '·'}</span></span>)}</div>
    <p className="streak-hint">День засчитывается за изучение теории или работу с ответами. Серия считается по местным датам устройства.</p>
    {error && <p className="learning-error" role="alert">{error}</p>}
  </section>
}
