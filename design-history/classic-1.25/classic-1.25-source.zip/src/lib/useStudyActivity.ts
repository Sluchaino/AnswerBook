import { useCallback, useEffect, useState } from 'react'
import { emptyActivity, parseActivity, recordStudyDay } from './activity'
import { activityKey, readStored, writeStored } from './storage'

export function useStudyActivity() {
  const [load]=useState(()=>{try{return {activity:parseActivity(readStored(activityKey)),failed:false}}catch{return {activity:emptyActivity(),failed:true}}})
  const [activity,setActivity]=useState(load.activity)
  const [saveFailed,setSaveFailed]=useState(false)
  const recordStudy=useCallback(()=>{if (!load.failed) setActivity(current=>{const next=recordStudyDay(current);return saveFailed ? {...next} : next})},[load.failed,saveFailed])
  useEffect(()=>{
    if(load.failed)return
    let active=true
    void writeStored(activityKey,JSON.stringify(activity)).then(()=>{if(active)setSaveFailed(false)},()=>{if(active)setSaveFailed(true)})
    return ()=>{active=false}
  },[activity,load.failed])
  return {activity,recordStudy,activityError:load.failed ? 'Не удалось прочитать историю занятий. Прежние данные сохранены.' : saveFailed ? 'Не удалось сохранить серию занятий на устройстве.' : ''}
}
