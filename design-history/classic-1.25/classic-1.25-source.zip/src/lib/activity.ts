export type StudyActivity = { version:1; days:string[] }
export const emptyActivity = ():StudyActivity => ({version:1,days:[]})
export function localStudyDay(now=new Date()) {
  return `${now.getFullYear()}-${String(now.getMonth()+1).padStart(2,'0')}-${String(now.getDate()).padStart(2,'0')}`
}
function ordinal(day:string) {
  const [year,month,date]=day.split('-').map(Number)
  return Date.UTC(year,month-1,date)/86400000
}
function validDay(day:unknown):day is string {
  if (typeof day!=='string' || !/^\d{4}-\d{2}-\d{2}$/.test(day)) return false
  return new Date(ordinal(day)*86400000).toISOString().slice(0,10)===day
}
export function parseActivity(raw:string|null):StudyActivity {
  if (raw===null) return emptyActivity()
  const value=JSON.parse(raw) as StudyActivity
  if (!value || value.version!==1 || !Array.isArray(value.days) || value.days.length>36600 || !value.days.every(validDay)) throw new Error('Неверная история занятий')
  return {version:1,days:[...new Set(value.days)].sort()}
}
export function recordStudyDay(activity:StudyActivity,now=new Date()):StudyActivity {
  const day=localStudyDay(now)
  return activity.days.includes(day) ? activity : {...activity,days:[...activity.days,day].sort()}
}
export function studyStreak(activity:StudyActivity,now=new Date()) {
  const today=localStudyDay(now),todayNumber=ordinal(today)
  const days=[...new Set(activity.days)].filter(day=>ordinal(day)<=todayNumber).sort()
  const set=new Set(days.map(ordinal))
  let current=0,best=0,run=0,last=-Infinity
  for (const day of days) {const n=ordinal(day);run=n===last+1 ? run+1 : 1;best=Math.max(best,run);last=n}
  let cursor=set.has(todayNumber) ? todayNumber : todayNumber-1
  while(set.has(cursor)) {current++;cursor--}
  const week=Array.from({length:7},(_,i)=>{const n=todayNumber-6+i;const day=new Date(n*86400000).toISOString().slice(0,10);return {day,active:set.has(n),today:n===todayNumber}})
  return {current,best,total:days.length,today:set.has(todayNumber),week}
}
