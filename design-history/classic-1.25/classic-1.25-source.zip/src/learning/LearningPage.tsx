import { useCallback, useEffect, useRef, useState, useSyncExternalStore } from 'react'
import { learningCourses, learningDirections } from '../lib/learningContent'
import { freshLearningAttempt, restoreLearningAttempt, learningScore, learningProgress } from '../lib/learning'
import { learningStorageKey, readStored, subscribeStorage, storageRevision } from '../lib/storage'
import { StudyStreak } from '../components/StudyStreak'
import type { StudyActivity } from '../lib/activity'
import { CoursePlayer } from './CoursePlayer'
import { Select } from '../components/Select'
import './learning.css'

const plural = new Intl.PluralRules('ru')
function count(n: number, one: string, few: string, many: string) {
  const form = plural.select(n)
  return `${n} ${form === 'one' ? one : form === 'few' ? few : many}`
}

const percentFormat=new Intl.NumberFormat('ru-RU',{minimumFractionDigits:2,maximumFractionDigits:2})
export function LearningPage({ initialCourseId,activity,activityError,onStudy }: { initialCourseId?: string | null;activity:StudyActivity;activityError:string;onStudy:()=>void }) {
  const [selected, setSelected] = useState(initialCourseId ?? null)
  const [mode, setMode] = useState<'learn' | 'exam' | 'result'>('learn')
  useSyncExternalStore(subscribeStorage,storageRevision,storageRevision)
  const [directionId, setDirectionId] = useState('all')
  const [, setRevision] = useState(0)
  const onSaved = useCallback(() => setRevision(n => n + 1), [])
  const heading = useRef<HTMLHeadingElement>(null)
  useEffect(() => { if (!selected) { heading.current?.focus(); window.scrollTo({ top:0 }) } }, [selected])
  const course = learningCourses.find(item => item.id === selected)
  if (course) return <CoursePlayer key={`${course.id}-${mode}`} course={course} mode={mode} onSaved={onSaved} onClose={() => setSelected(null)} onStudy={onStudy} />
  return <section className="learning-page">
    <div className="learning-intro"><span className="eyebrow">ПОНЯТЬ, ПОПРОБОВАТЬ, ЗАКРЕПИТЬ</span><h1 ref={heading} tabIndex={-1}>Учиться <span className="serif">с пониманием.</span></h1><p>{count(learningCourses.length, 'курс', 'курса', 'курсов')} · {count(learningDirections.length, 'направление', 'направления', 'направлений')}. Теория и проверка знаний — в своём темпе и без интернета.</p></div>
    <StudyStreak activity={activity} error={activityError} />
    <Select label="Направление" value={directionId} onChange={setDirectionId} options={[{value:'all',label:'Все направления'}, ...learningDirections.map(direction => ({value:direction.id,label:direction.title}))]} />
    {learningDirections.filter(direction => directionId === 'all' || direction.id === directionId).map(direction => <section className="learning-direction" key={direction.id} aria-labelledby={`direction-${direction.id}`}>
    <div className="learning-direction-heading"><h2 id={`direction-${direction.id}`}>{direction.title}</h2><p>{direction.description} · {count(learningCourses.filter(item => item.direction === direction.id).length, 'курс', 'курса', 'курсов')}</p></div>
    <div className="learning-course-grid">{learningCourses.filter(item => item.direction === direction.id).map(item => {
      let attempt = freshLearningAttempt(item), failed = false
      try { attempt = restoreLearningAttempt(readStored(learningStorageKey(item.id)), item,item.previous) }
      catch { failed = true }
      const score = learningScore(item, attempt)
      const progress = learningProgress(item,attempt)
      const outputs = item.lessons.flatMap(lesson => lesson.questions).filter(q => q.kind === 'output').length
      return <article className="learning-course-card" key={item.id} aria-labelledby={`course-title-${item.id}`}>
        <span className={`topic-symbol ${item.color}`}>{item.symbol}</span><span className="learning-badge">Теория + тест</span>
        <h3 id={`course-title-${item.id}`}>{item.title}</h3><p>{item.description}</p>
        <p className="learning-scope">{item.scope === 'universal' ? 'Универсальный курс' : 'Для C# / .NET'}</p>
        <div className="learning-card-stats"><span>{count(item.lessons.length, 'блок', 'блока', 'блоков')}</span><span>{count(score.total, 'задание', 'задания', 'заданий')}</span>{outputs > 0 && <span>{count(outputs, 'задача', 'задачи', 'задач')} на результат</span>}</div>
        <p className="learning-source">{item.sources.map(source => source.file).join(' + ')} · {count(item.pageCount, 'страница', 'страницы', 'страниц')}</p>
        {!failed && progress.started && <div className="learning-card-progress"><div><span>{attempt.finished ? 'Курс пройден' : 'Прогресс прохождения'}</span><strong>{percentFormat.format(progress.percent)}%</strong></div><progress value={progress.percent} max={100} aria-label={`Прогресс курса ${item.title}`} /></div>}
        {attempt.lastResult && <p className="learning-last-score">Последний результат: {attempt.lastResult.correct}/{attempt.lastResult.total} · точность {percentFormat.format(attempt.lastResult.percent)}%</p>}
        <div className="learning-course-actions"><button className="primary" disabled={failed} aria-label={attempt.finished ? `Открыть результат: ${item.title}` : `${score.answered ? 'Продолжить' : 'Открыть'} курс: ${item.title}`} onClick={() => { setMode(attempt.finished ? 'result' : 'learn'); setSelected(item.id) }}>{attempt.finished ? 'Открыть результат' : score.answered ? `Продолжить · ${score.answered} из ${score.total}` : 'Открыть курс'} <span aria-hidden="true">↗</span></button>{attempt.lastResult && !attempt.finished && <button className="secondary" onClick={()=>{setMode('result');setSelected(item.id)}}>Последний результат</button>}<button className="secondary" disabled={failed} aria-label={`Сдать досрочно: ${item.title}`} onClick={() => { setMode('exam'); setSelected(item.id) }}>Сдать досрочно</button></div>
        {failed && <p className="learning-error" role="alert">Не удалось прочитать сохранение этого курса. Перезапустите приложение; прежние данные не перезаписаны.</p>}
      </article>
    })}</div></section>)}
  </section>
}
